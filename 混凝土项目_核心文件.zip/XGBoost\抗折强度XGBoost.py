# 广东工业大学
# 李俊赞
#  开发时间:  9/13/2023 7:40 下午
# 导入需要的包
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, accuracy_score, auc, recall_score, precision_score, f1_score, r2_score
from sklearn.metrics import roc_curve, precision_recall_curve, average_precision_score
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from xgboost import plot_importance
import warnings
import matplotlib

matplotlib.use('TkAgg')
plt.rcParams['font.sans-serif'] = ['KaiTi']

# 加载数据集，这里直接使用datasets包里面的乳腺癌分类数据（二分类）
data = pd.read_excel('../数据文件/数据集完善.xlsx', sheet_name="抗折强度")
X = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 16])
le = LabelEncoder()
y = le.fit_transform(y)
y = y.ravel()
feature_names = ['水泥强度等级(MPa)', '水泥含量', '粉煤灰含量', '矿粉含量', '硅灰含量', '水胶比', '胶砂比', '减水剂掺量(%)', '增稠剂掺量(%)', '速凝剂掺量(%)',
                 '缓凝剂掺量(%)', '保水剂掺量(%)', '纤维含量(%)']
feature_names = list(feature_names)
# 输出数据集的形状，该数据集里面有569个样本，每个样本有30个特征(569, 30)
print(X.shape)
# 输出标签的个数为 569
print(y.shape)
# 使用train_test_split()函数对训练集和测试集进行划分，第一个参数是数据集特征，第二个参数是标签，第三个为测试集占总样本的百分比
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=6)
warnings.filterwarnings("ignore")  # 忽略警告信息
y_train = le.fit_transform(y_train)  # 对训练集目标变量进行编码
# 使用XGBoost进行训练
model = XGBClassifier()
model.fit(x_train, y_train)
model.get_booster().feature_names = feature_names
# 绘制重要性曲线, max_num_feature参数设置输出前30重要的特征,【数据集中共有30个特征】
# fig, ax = plt.subplots(figsize=(16, 10))
# figure1 = plot_importance(model, ax=ax, grid=False)
# plt.show()
# 类别值
y_pred = model.predict(x_test)
y_pred = le.inverse_transform(y_pred)  # 将预测结果反编码
# 输出ACC的值
acc = accuracy_score(y_test, y_pred)
print("acc:", acc)
print('R方=', r2_score(y_test, y_pred))
plt.plot(y_test, color='#006F6E', label='Test Values')
plt.plot(y_pred, color='#FF9C29', label='Predicted Values')
plt.legend()
plt.grid(False)
plt.title("抗折强度XGBoost")
plt.savefig("抗折强度XGBoost.png")
plt.show()
#  # 输出recall值
# re = recall_score(y_test, y_pred)
# print("recall:", re)
#  # 输出precision
# pre = precision_score(y_test, y_pred)
# print("precision:", pre)
#  # 输出f1 score
# f1 = f1_score(y_test, y_pred)
# print("f1 score:", f1)
#  # 概率得分
# y_score = model.predict_proba(x_test)[:,1]
#  # 直接计算auc的值
# auc_1 = roc_auc_score(y_test, y_score)
# print("auc_1:", auc_1)
#  # 绘制ROC曲线
# fpr, tpr, thresholds_roc = roc_curve(y_test, y_score)
# # 间接计算auc的值
# auc_2 = auc(fpr, tpr)
# print("auc_2:", auc_2)
#  # 间接计算auc的值的好处，就是可以知道fpr和tpr，绘制曲线
# plt.plot(fpr,tpr,'r--', label='auc=%0.4f'%auc_2)
# plt.title("ROC Curve")
# plt.legend()
# plt.show()
#  # 绘制PR曲线
# precision, recall, thresholds_pr = precision_recall_curve(y_test, y_score)
# aupr = auc(recall, precision)
# print("aupr:", aupr)
# plt.plot(recall, precision, 'g--', label='aupr=%0.4f'%aupr)
# plt.title("PR Curve")
# plt.legend()
# plt.show()
