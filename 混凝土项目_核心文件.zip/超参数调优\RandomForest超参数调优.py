import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn import metrics, ensemble

# 导入数据
pd.set_option('display.max_columns', None)  # 结果显示所有列
pd.set_option('display.max_rows', None)  # 结果显示所行行
data2 = pd.read_csv('testdata.csv')
data1, data2 = train_test_split(data2, test_size=0.3)
# 创建训练集
train_x = data1.iloc[:, 0:9]
train_y = data1.iloc[:, 9]
parameters = {'n_estimators': [50, 100, 150, 200],
              'max_depth': np.linspace(5, 18, 14),
              'min_samples_split': [int(x) for x in np.linspace(1, 3, 3)]
              }
print(parameters, type(parameters))
xlf = ensemble.RandomForestRegressor()

n_folds = 5
gsearch = GridSearchCV(xlf, param_grid=parameters, cv=n_folds, refit=True,
                       scoring='r2')  # 原来这个scoring是自己定义的，鸡儿了，一般scoring默认就是就是用R方
gsearch.fit(train_x, train_y)

print("Best score: %0.3f" % gsearch.best_score_)
for param_name in sorted(parameters.keys()):
    print("\t%s: %r" % (param_name, gsearch.best_params_[param_name]))
