import numpy as np
from matplotlib import pyplot as plt
from sklearn.multioutput import MultiOutputRegressor
import xgboost as xgb
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split

plt.rcParams['font.sans-serif'] = ['KaiTi']
import warnings
import matplotlib

matplotlib.use('TkAgg')

warnings.filterwarnings("ignore")  # 忽略警告信息
# 获取数据
data = pd.read_excel("../数据文件/数据集完善.xlsx", sheet_name="抗压强度")
X = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 15:16])


data1 = pd.read_excel("../数据文件/数据集完善.xlsx")

x1 = np.array(data.iloc[:, 2:15])
y1 = np.array(data.iloc[:, 15:16])

train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=4)
# 准备参数
other_params = {'learning_rate': 0.2, 'n_estimators': 300, 'max_depth': 5, 'min_child_weight': 1, 'seed': 2,
                'subsample': 0.8, 'colsample_bytree': 0.8, 'gamma': 0, 'reg_alpha': 0, 'reg_lambda': 1}

multioutputregressor = MultiOutputRegressor(
    xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)

check = multioutputregressor.predict(test_X)
print(check)
print(test_y)
r2 = r2_score(check, test_y)
print("计算得出的r方为：", r2)

plt.title("XGBoost抗压强度回归")
plt.plot(test_y, label="原值")
plt.plot(check, c='r', label="预测值")
plt.legend()
plt.show()
