# 广东工业大学
# 李俊赞
#  开发时间:  9/18/2023 8:21 下午
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from bayes_opt import BayesianOptimization
import matplotlib
import matplotlib.pyplot as plt

matplotlib.use('TkAgg')
plt.rcParams['font.sans-serif'] = ['KaiTi']
# 读取数据
data = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据文件\数据集完善.xlsx", sheet_name="流动度")
x = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 19:20])
feature_names = ['水泥强度等级(MPa)', '水泥含量', '粉煤灰含量', '矿粉含量', '硅灰含量', '水胶比', '胶砂比', '减水剂掺量(%)', '增稠剂掺量(%)', '速凝剂掺量(%)',
                 '缓凝剂掺量(%)', '保水剂掺量(%)', '纤维含量(%)']
X = x
train_X, val_X, train_y, y_true = train_test_split(X, y, random_state=1)
train_y = train_y.ravel()

# 定义目标函数（即要最大化的函数）
def target_function(n_estimators, max_depth, min_samples_split, min_samples_leaf):
    model = RandomForestRegressor(n_estimators=int(n_estimators), max_depth=int(max_depth),
                                  min_samples_split=int(min_samples_split), min_samples_leaf=int(min_samples_leaf),
                                  random_state=4)
    model.fit(train_X, train_y)
    y_pred = model.predict(val_X)
    r2 = r2_score(y_true, y_pred)
    return r2

# 定义参数空间
pbounds = {'n_estimators': (10, 1000),
           'max_depth': (1, 20),
           'min_samples_split': (2, 20),
           'min_samples_leaf': (1, 20)}

# 使用贝叶斯优化算法搜索最佳参数组合
optimizer = BayesianOptimization(f=target_function, pbounds=pbounds)
optimizer.maximize(init_points=10, n_iter=50)

# 打印最佳参数组合和对应的R2分数
best_params = optimizer.max['params']
best_r2 = optimizer.max['target']
print("最佳参数组合：", best_params)
print("最大R2分数：", best_r2)

# 使用最佳参数组合进行模型训练和预测
model = RandomForestRegressor(n_estimators=int(best_params['n_estimators']), max_depth=int(best_params['max_depth']),
                              min_samples_split=int(best_params['min_samples_split']),
                              min_samples_leaf=int(best_params['min_samples_leaf']), random_state=4)
model.fit(train_X, train_y)
y_pred = model.predict(val_X)

# 打印优化后的R2分数
optimized_r2 = r2_score(y_true, y_pred)
print("优化后的R2分数：", optimized_r2)

# 绘制预测结果
import matplotlib.pyplot as plt
plt.plot(y_true, color='#006F6E', label='真实值')
plt.plot(y_pred, color='#FF9C29', label='预测值')
plt.title("贝叶斯随机森林流动预测", fontsize=12)
plt.legend()
plt.show()