import numpy as np
from matplotlib import pyplot as plt
from sklearn.multioutput import MultiOutputRegressor
import xgboost as xgb
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold, cross_val_score

plt.rcParams['font.sans-serif'] = ['SimHei']
import warnings

warnings.filterwarnings("ignore")  # 忽略警告信息
# 获取数据
data = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据集完善.xlsx")
X = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 19:20])

data1 = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据集完善.xlsx")
x1 = np.array(data1.iloc[:, 2:15])
y1 = np.array(data1.iloc[:, 19:20])

# 准备参数
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=4)
other_params = {'learning_rate': 0.2, 'n_estimators': 300, 'max_depth': 5, 'min_child_weight': 1, 'seed': 2,
                'subsample': 0.8, 'colsample_bytree': 0.8, 'gamma': 0, 'reg_alpha': 0, 'reg_lambda': 1}


# 指定要折几下
kf = KFold(n_splits=5)

coefs = []
scores = []
for train, test in kf.split(X):
    # 遍历样本
    train_X, test_X = X[train], X[test]
    train_y, test_y = y[train], y[test]
    # 训练模型
    multi_output_regressor = MultiOutputRegressor(
    xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)
    # check = multi_output_regressor.predict(test_X)
    coefs.append(pd.DataFrame(multi_output_regressor.coef_))
    scores.append(multi_output_regressor.score(test_X, test_y))
    # 拟合模型
    model = multi_output_regressor()
    scores1 = cross_val_score(model, X1, y1, cv=5)
    scores2 = cross_val_score(model, X2, y2, cv=5)
    scores3 = cross_val_score(model, X3, y3, cv=5)
    scores4 = cross_val_score(model, X4, y4, cv=5)
    scores5 = cross_val_score(model, X5, y5, cv=5)

    # print(check)
    # print(test_y)
    # r2 = r2_score(check, test_y)
    # print("计算得出的r方为：", r2)
    # plt.title("XGBoost 回归")
    # plt.plot(test_y, label="原值")
    # plt.plot(check, c='r', label="预测值")
    # plt.legend()
    # plt.show()

