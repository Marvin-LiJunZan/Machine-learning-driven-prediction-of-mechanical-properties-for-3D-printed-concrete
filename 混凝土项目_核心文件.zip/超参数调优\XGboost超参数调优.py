import numpy as np
import xgboost as xgb
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import GridSearchCV
import joblib
from sklearn import metrics, ensemble

'''cancer = load_breast_cancer()
x = cancer.data[:50]
y = cancer.target[:50]'''
#train_x, valid_x, train_y, valid_y = train_test_split(x, y, test_size=0.333, random_state=0)  # 分训练集和验证集'''
# 这里不需要Dmatrix

pd.set_option('display.max_columns', None)  # 结果显示所有列
pd.set_option('display.max_rows', None)  # 结果显示所行行

#1.tgan合成的训练集
#data1 = pd.read_csv('traindata.csv')
#data2 = pd.read_csv('testdata.csv')

#2.原数据225个原数据7：3拆分
data2 = pd.read_csv('testdata.csv')
data1, data2 = train_test_split(data2, test_size=0.3)
train_x = data1.iloc[:, 0:9]
train_y = data1.iloc[:, 9]

#X = pd.concat([x_train, x_test])
#Y = pd.concat([y_train, y_test])
#col = data1.columns[:-1]


parameters = {'learning_rate': np.linspace(0.1, 1, 5),
              'subsample': np.linspace(0.1, 1, 5),
              # 'colsample_bynode': np.linspace(0.1, 1, 5),
              # 'reg_lambda': np.linspace(1e-6, 1e-4, 5)
              }

print(parameters, type(parameters))

xlf = xgb.XGBRegressor()
# 有了gridsearch我们便不需要fit函数
n_folds = 5
gsearch = GridSearchCV(xlf, param_grid=parameters, cv=n_folds, refit=True)
gsearch.fit(train_x, train_y)
#print('训练验证集上交叉验证的得分:', gsearch.best_score_)
#print('最优参数组合:', gsearch.best_params_)

print("Best score: %0.3f" % gsearch.best_score_)
#print("Best parameters set:", gsearch.best_params_)
#best_parameters = gsearch.best_params_()
for param_name in sorted(parameters.keys()):
    print("\t%s: %r" % (param_name, gsearch.best_params_[param_name]))