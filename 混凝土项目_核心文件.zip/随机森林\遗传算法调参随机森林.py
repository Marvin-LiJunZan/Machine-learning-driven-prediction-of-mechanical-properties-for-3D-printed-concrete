import random
import matplotlib.pyplot as plt
from deap import base, creator, tools, algorithms
from sklearn.ensemble import RandomForestRegressor
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

plt.rcParams['font.sans-serif'] = ['SimHei']
# data = pd.read_excel(r"../数据集完善-抗压.xlsx")
# x = np.array(data.iloc[:,:13])
# y = np.array(data.iloc[:,13:14])
# feature_names =['水泥强度等级(MPa)','水泥含量','粉煤灰含量','矿粉含量','硅灰含量','水胶比','胶砂比','减水剂掺量(%)','增稠剂掺量(%)','速凝剂掺量(%)','缓凝剂掺量(%)','保水剂掺量(%)','纤维含量(%)']

# data = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据文件\数据集完善.xlsx", sheet_name="抗压强度")
# x = np.array(data.iloc[:, 2:15])
# y = np.array(data.iloc[:, 15:16])
# feature_names = ['水泥强度等级(MPa)', '水泥含量', '粉煤灰含量', '矿粉含量', '硅灰含量', '水胶比', '胶砂比', '减水剂掺量(%)', '增稠剂掺量(%)', '速凝剂掺量(%)',
#                  '缓凝剂掺量(%)', '保水剂掺量(%)', '纤维含量(%)']

data = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据文件\数据集完善修改版.xlsx", sheet_name="抗压强度")
x = np.array(data.iloc[:, 2:17])
y = np.array(data.iloc[:, 17:18])
feature_names = ['PO水泥强度等级(MPa)', 'PO水泥含量', 'SAC水泥强度等级(MPa)', 'SAC水泥含量', '粉煤灰含量', '矿粉含量', '硅灰含量',
                 '水胶比', '胶砂比', '减水剂掺量(%)', '增稠剂掺量(%)', '速凝剂掺量(%)', '缓凝剂掺量(%)', '保水剂掺量(%)', '纤维含量(%)']

train_X, test_X, train_y, y_test = train_test_split(x, y, test_size=0.3, random_state=1)
train_y = train_y.ravel()


# 定义适应度函数
def evaluate(individual):
    # 从个体中提取超参数
    n_estimators, max_depth, max_features_value = individual

    # 确保 max_features_value 在合法范围内 (0, 1]
    max_features_value = max(0.01, min(max_features_value, 1.0))

    # 计算实际的 max_features 值
    # 在 evaluate 函数中
    max_features = max(1, int(max_features_value * n_features))

    # 确保 n_estimators 大于零
    n_estimators = max(n_estimators, 1)

    # 使用指定的超参数创建一个随机森林回归模型
    model = RandomForestRegressor(n_estimators=int(n_estimators), max_depth=int(max_depth), max_features=max_features,
                                  random_state=4)

    # 训练模型
    model.fit(train_X, train_y)

    # 在测试集上进行预测
    y_pred = model.predict(test_X)

    # 计算R^2分数作为适应度值（最大化R^2分数）
    fitness = r2_score(y_test, y_pred)

    return fitness,


# 定义优化问题
creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)
toolbox = base.Toolbox()

# 定义参数搜索空间
toolbox.register("n_estimators", random.randint, 1, 100)  # 修改范围，确保不包括0
toolbox.register("max_depth", random.randint, 1, 30)
n_features = len(feature_names)
# 修改 max_features_value 注册
toolbox.register("max_features_value", random.uniform, 0.0, 1.0)


# 创建一个个体
# 创建一个个体
def create_individual():
    n_estimators = random.randint(1, 100)  # 修改范围，确保不包括0
    max_depth = random.randint(1, 30)
    max_features_value = random.uniform(0.0, 1.0)

    return creator.Individual((n_estimators, max_depth, max_features_value))


toolbox.register("individual", create_individual)

toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 注册评估函数
toolbox.register("evaluate", evaluate)

# 定义遗传算法的操作
toolbox.register("mate", tools.cxBlend, alpha=0.5)
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.2)

# 定义选择操作
toolbox.register("select", tools.selTournament, tournsize=3)

# 创建初始种群
population = toolbox.population(n=10)

# 创建用于跟踪演化的统计对象
stats = tools.Statistics(lambda ind: ind.fitness.values)
stats.register("max", max)

# 执行遗传算法优化
num_generations = 1000
num_individuals = 10
cx_prob = 0.7
mut_prob = 0.2

pop, log = algorithms.eaSimple(population, toolbox, cxpb=cx_prob, mutpb=mut_prob,
                               ngen=num_generations, stats=stats, verbose=True)

# 获取最佳个体
best_individual = tools.selBest(pop, 1)[0]

# 提取最佳超参数
best_n_estimators, best_max_depth, best_max_features_value = best_individual

# 创建具有最佳超参数的最终随机森林回归模型
best_model = RandomForestRegressor(
    n_estimators=int(best_n_estimators),
    max_depth=int(best_max_depth),
    max_features=int(best_max_features_value),  # max_features不需要再转换为整数
    random_state=4
)

# 训练最佳模型
best_model.fit(train_X, train_y)

# 在测试集上进行预测
y_pred = best_model.predict(test_X)

# 评估最终模型
print('最佳R^2分数:', r2_score(y_test, y_pred))
print('最佳超参数值: n_estimators={}, max_depth={}, max_features_value={}'.format(
    int(best_n_estimators), int(best_max_depth), best_max_features_value
))
y_test = y_test.ravel()
print('相关系数=', np.corrcoef(y_test, y_pred)[0, 1])
