# 广东工业大学
# 李俊赞
#  开发时间:  9/17/2023 3:24 下午


import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from Concrete_Designer import *


class MyMainWindow(QMainWindow, Ui_MainWindow):
