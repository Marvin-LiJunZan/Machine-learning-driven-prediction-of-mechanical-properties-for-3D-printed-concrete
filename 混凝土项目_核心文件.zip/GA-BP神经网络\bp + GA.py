import matplotlib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import MinMaxScaler
from scipy.special import expit
import matplotlib.pyplot as plt

matplotlib.use('TkAgg')
plt.rcParams['font.sans-serif'] = ['SimHei']

data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1211长细比.xlsx", sheet_name="流动度校核")
X = np.array(data.iloc[:, 2:28])
y = np.array(data.iloc[:, 28:29])

# 加载数据
# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1127.xlsx", sheet_name='流动度')
# X = np.array(data.iloc[:, 2:19])
# y = np.array(data.iloc[:, 19:20])
# z = np.array(data.iloc[:, 2])
# plt.scatter(z, y)
# plt.show()

# 数据归一化
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
y_scaled = scaler.fit_transform(y)

# 划分训练集和测试集
train_X, test_X, train_y, test_y = train_test_split(X_scaled, y_scaled, test_size=0.3, random_state=4)
#
# 定义遗传算法优化的BP神经网络类
class GeneticAlgorithmBPNN:
    def __init__(self, population_size, chromosome_length, learning_rate, max_iterations):
        self.population_size = population_size
        self.chromosome_length = chromosome_length
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations

    def initialize_population(self):
        population = np.random.uniform(low=-1, high=1, size=(self.population_size, self.chromosome_length))
        return population

    def decode_chromosome(self, chromosome):
        num_hidden_layers = int(chromosome[0])
        hidden_layer_sizes = []
        start = 1
        for i in range(num_hidden_layers):
            hidden_layer_size = int(chromosome[start])
            hidden_layer_sizes.append(hidden_layer_size)
            start += hidden_layer_size
        output_layer_size = 1
        return num_hidden_layers, hidden_layer_sizes, output_layer_size

    def forward_propagation(self, X, weights, biases):
        num_hidden_layers, hidden_layer_sizes, output_layer_size = self.decode_chromosome(weights)

        # 输入层到第一个隐藏层
        hidden_layer_inputs = np.dot(X, weights[1: hidden_layer_sizes[0] + 1]) + biases[0]
        hidden_layer_outputs = expit(hidden_layer_inputs)

        # 隐藏层之间的传播
        start = hidden_layer_sizes[0] + 1
        for i in range(num_hidden_layers - 1):
            hidden_layer_inputs = np.dot(hidden_layer_outputs, weights[start: start + hidden_layer_sizes[i + 1], :]) + \
                                  biases[i + 1]
            hidden_layer_outputs = expit(hidden_layer_inputs)

        # 最后一个隐藏层到输出层
        output_layer_inputs = np.dot(hidden_layer_outputs, weights[start + hidden_layer_sizes[-1]:, :]) + biases[-1]
        output_layer_outputs = expit(output_layer_inputs)

        return output_layer_outputs

    def calculate_fitness(self, X, y, weights, biases):
        predicted_y = self.forward_propagation(X, weights, biases)
        fitness = r2_score(y, predicted_y)
        return fitness

    def crossover(self, parent1, parent2):
        child = np.copy(parent1)
        crossover_point = np.random.randint(1, self.chromosome_length)
        child[crossover_point:] = parent2[crossover_point:]
        return child

    def mutation(self, chromosome):
        mutation_point = np.random.randint(0, self.chromosome_length)
        chromosome[mutation_point] = np.random.uniform(low=-1, high=1)
        return chromosome

    def train(self, X, y):
        population = self.initialize_population()
        best_fitness = -np.inf
        best_weights = None
        best_biases = None

        for iteration in range(self.max_iterations):
            fitness_values = []

            # 计算每个个体的适应度
            for i in range(self.population_size):
                weights = population[i, :self.chromosome_length // 2]
                biases = population[i, self.chromosome_length // 2:]
                fitness = self.calculate_fitness(X, y, weights, biases)
                fitness_values.append(fitness)

                # 更新最佳适应度和最佳权重
                if fitness > best_fitness:
                    best_fitness = fitness
                    best_weights = weights
                    best_biases = biases

            # 选择父代进行交叉和变异
            new_population = []
            for i in range(self.population_size // 2):
                parent1 = population[np.argmax(fitness_values)]
                parent2 = population[np.argmin(fitness_values)]
                child1 = self.crossover(parent1, parent2)
                child2 = self.crossover(parent2, parent1)
                child1 = self.mutation(child1)
                child2 = self.mutation(child2)
                new_population.extend([child1, child2])

            population = np.array(new_population)

        return best_weights, best_biases

# 设置遗传算法BP神经网络的参数
population_size = 50
chromosome_length = 100
learning_rate = 0.01
max_iterations = 100

# 创建遗传算法BP神经网络对象并训练模型
ga_bpnn = GeneticAlgorithmBPNN(population_size, chromosome_length, learning_rate, max_iterations)
best_weights, best_biases = ga_bpnn.train(train_X, train_y)

# 使用最佳权重和偏置进行预测
predicted_y = ga_bpnn.forward_propagation(test_X, best_weights, best_biases)

# 反归一化预测结果
predicted_y = scaler.inverse_transform(predicted_y)
test_y = scaler.inverse_transform(test_y)

# 计算评估指标
r2 = r2_score(test_y, predicted_y)
mae = mean_absolute_error(test_y, predicted_y)
mse = mean_squared_error(test_y, predicted_y)
rmse = np.sqrt(mse)

# 打印评估指标
print("R2 Score:", r2)
print("Mean Absolute Error:", mae)
print("Mean Squared Error:", mse)
print("Root Mean Squared Error:", rmse)