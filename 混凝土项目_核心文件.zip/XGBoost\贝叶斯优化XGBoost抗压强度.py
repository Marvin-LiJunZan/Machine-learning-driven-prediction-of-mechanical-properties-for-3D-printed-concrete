# 广东工业大学
# 李俊赞
#  开发时间:  9/18/2023 7:40 下午
import numpy as np
from matplotlib import pyplot as plt
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import MinMaxScaler
import xgboost as xgb
import pandas as pd
from sklearn.metrics import r2_score, explained_variance_score
from sklearn.model_selection import train_test_split
from bayes_opt import BayesianOptimization
from sklearn import metrics
plt.rcParams['font.sans-serif'] = ['KaiTi']
import warnings
import matplotlib

matplotlib.use('TkAgg')
warnings.filterwarnings("ignore")  # 忽略警告信息


# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1211长细比.xlsx", sheet_name="流动度校核")
# X = np.array(data.iloc[:, 2:28])
# y = np.array(data.iloc[:, 28:29])

# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1211长细比.xlsx", sheet_name="去长细比")
# X = np.array(data.iloc[:, 2:27])
# y = np.array(data.iloc[:, 27:28]

# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1211长细比.xlsx", sheet_name="去石灰石流动度")
# X = np.array(data.iloc[:, 2:27])
# y = np.array(data.iloc[:, 27:28])

# 获取数据
# data = pd.read_excel("../数据文件/数据集完善.xlsx", sheet_name="抗压强度")
# X = np.array(data.iloc[:, 2:15])
# y = np.array(data.iloc[:, 15:16])


# 1.1 不删任何自变量抗压
# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1213长细比.xlsx", sheet_name='全抗压')
# X = np.array(data.iloc[:, 2:19])
# y = np.array(data.iloc[:, 19:20])

data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1213长细比.xlsx", sheet_name='全抗压')
X = np.array(data.iloc[:, 2:20])
y = np.array(data.iloc[:, 20:21])

# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1213长细比.xlsx", sheet_name='去石灰石粉抗压')
# X = np.array(data.iloc[:, 2:18])
# y = np.array(data.iloc[:, 18:19])


# 0.2 流动度校核
# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1209.xlsx", sheet_name='流动度校核')
# X = np.array(data.iloc[:, 2:26])
# y = np.array(data.iloc[:, 26:27])

# 2.0 一种水泥
# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1127.xlsx", sheet_name='一种水泥')
# X = np.array(data.iloc[:, 2:17])
# y = np.array(data.iloc[:, 17:18])
'''
使用最佳参数组合计算得出的R2值： 0.9418032580689017
平均绝对误差: 5.2310813791323945
平均平方误差: 58.96629593001575
均方根误差: 7.678951486369461
'''

# 2.1 摘别人的
# data = pd.read_excel(r"C:\Marvin's project\1128\data\数据集1127.xlsx", sheet_name='摘别人的')
# X = np.array(data.iloc[:, 1:8])
# y = np.array(data.iloc[:, 8:9])




# 归一化处理
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
y_scaled = scaler.fit_transform(y)
train_X, test_X, train_y, test_y = train_test_split(X_scaled, y_scaled, test_size=0.3, random_state=4)


# 定义目标函数（即要最大化的函数）
def target_function(learning_rate, n_estimators, max_depth, min_child_weight, seed, subsample, colsample_bytree, gamma,
                    reg_alpha, reg_lambda):
    other_params = {'learning_rate': learning_rate, 'n_estimators': int(n_estimators), 'max_depth': int(max_depth),
                    'min_child_weight': int(min_child_weight), 'seed': int(seed), 'subsample': subsample,
                    'colsample_bytree': colsample_bytree, 'gamma': gamma, 'reg_alpha': reg_alpha,
                    'reg_lambda': reg_lambda}
    multioutputregressor = MultiOutputRegressor(
        xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)
    check = multioutputregressor.predict(test_X)
    r2 = r2_score(check, test_y)
    return r2

# 定义参数空间
pbounds = {'learning_rate': (0.01, 1), 'n_estimators': (10, 500), 'max_depth': (1, 100),
           'min_child_weight': (1,100), 'seed': (1, 20), 'subsample': (0.001, 1), 'colsample_bytree': (0.01, 1),
           'gamma': (0, 1), 'reg_alpha': (0, 1), 'reg_lambda': (0, 1)}

# 最佳参数组合： {'colsample_bytree': 1.0, 'gamma': 0.0, 'learning_rate': 0.01, 'max_depth': 21.584867189201592, 'min_child_weight': 1.0, 'n_estimators': 389.037714104241, 'reg_alpha': 0.0, 'reg_lambda': 1.0, 'seed': 1.0, 'subsample': 1.0}
# 最佳R2值： 0.938749046739327
# [19:45:51] WARNING: C:\Users\dev-admin\croot2\xgboost-split_1675461376218\work\src\learner.cc:767:
# Parameters: { "silent" } are not used.
# MAE: 0.027437405570801578
# MSE: 0.0018329276556815171
# MAPE: 0.38991160226277405
# RMSE: 0.04281270437243503
# R方= 0.9457508352291928
# EVS= 0.949729772310342

# 定义参数空间
# pbounds = {'learning_rate': (0.01, 1), 'n_estimators': (50, 500), 'max_depth': (1, 10),
#            'min_child_weight': (1,100), 'seed': (1, 20), 'subsample': (0.001, 1), 'colsample_bytree': (0.01, 1),
#            'gamma': (0, 1), 'reg_alpha': (0, 1), 'reg_lambda': (0, 1)}

# 最佳参数组合： {'colsample_bytree': 1.0, 'gamma': 0.0, 'learning_rate': 1.0, 'max_depth': 9.72542746663574, 'min_child_weight': 27.72432507063361, 'n_estimators': 50.0, 'reg_alpha': 0.0, 'reg_lambda': 1.0, 'seed': 1.0, 'subsample': 1.0}
# 最佳R2值： 0.9125530442270449
# [19:37:57] WARNING: C:\Users\dev-admin\croot2\xgboost-split_1675461376218\work\src\learner.cc:767:
# Parameters: { "silent" } are not used.
# MAE: 0.0343192927653393
# MSE: 0.002623081422506239
# MAPE: 0.41385786959035625
# RMSE: 0.0512160270082153
# R方= 0.9223646520604905
# EVS= 0.9235685955537742

# 使用贝叶斯优化算法搜索最佳参数组合
optimizer = BayesianOptimization(f=target_function, pbounds=pbounds)
optimizer.maximize(init_points=10, n_iter=500)   # 在这里调整迭代次数

# 打印最佳参数组合和对应的R2值
best_params = optimizer.max['params']
best_r2 = optimizer.max['target']
print("最佳参数组合：", best_params)
print("最佳R2值：", best_r2)

# 使用最佳参数组合进行模型训练和预测
other_params = {'learning_rate': best_params['learning_rate'], 'n_estimators': int(best_params['n_estimators']),
                'max_depth': int(best_params['max_depth']), 'min_child_weight': int(best_params['min_child_weight']),
                'seed': int(best_params['seed']), 'subsample': best_params['subsample'],
                'colsample_bytree': best_params['colsample_bytree'], 'gamma': best_params['gamma'],
                'reg_alpha': best_params['reg_alpha'], 'reg_lambda': best_params['reg_lambda']}

multioutputregressor = MultiOutputRegressor(
    xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)

y_pred = multioutputregressor.predict(test_X)

print('MAE:', metrics.mean_absolute_error(test_y, y_pred))
print('MSE:', metrics.mean_squared_error(test_y, y_pred))
print('MAPE:', np.sqrt(metrics.mean_absolute_percentage_error(test_y, y_pred)))
print('RMSE:', np.sqrt(metrics.mean_squared_error(test_y, y_pred)))
print('R方=', r2_score(test_y, y_pred))
print('EVS=', explained_variance_score(test_y, y_pred))

# 绘制预测结果
plt.title("Bayesian optimization of XGBoost compressive strength regression")
plt.plot(test_y, label="test_y")
plt.plot(y_pred, c='r', label="predict_y")
plt.legend()
plt.show()