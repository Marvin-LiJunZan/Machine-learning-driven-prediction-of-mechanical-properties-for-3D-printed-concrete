from numpy import dtype
from sklearn.neural_network import MLPClassifier
import pandas as pd

# 读入 CSV 数据
df = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据集完善.xlsx")
# 将数据分成输入数据和标签
X = df.iloc[:, 2:15]
y = df['流动度(mm)'].iloc[:]
y = y.astype('int')
# 构建 BP 神经网络模型
# 设定MLP神经网络的参数

mlp = MLPClassifier(hidden_layer_sizes=[28, 28], max_iter=5000, random_state=62)

# 使用MLP拟合数据
mlp.fit(X, y)

# 打印模型得分
print('权重', mlp.coefs_)
print('模型得分:{:.2f}'.format(mlp.score(X, y)))
