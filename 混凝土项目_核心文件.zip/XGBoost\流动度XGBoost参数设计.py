import numpy as np
from matplotlib import pyplot as plt
from sklearn.multioutput import MultiOutputRegressor
import xgboost as xgb
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
import random
import warnings
import matplotlib

plt.rcParams['font.sans-serif'] = ['KaiTi']
matplotlib.use('TkAgg')
warnings.filterwarnings("ignore")  # 忽略警告信息

'''获取数据'''
data = pd.read_excel("../数据文件/数据集完善.xlsx", sheet_name="流动度")
X = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 19:20])

data1 = pd.read_excel("../数据文件/数据集完善.xlsx", sheet_name="流动度")
x1 = np.array(data.iloc[:, 2:15])
y1 = np.array(data.iloc[:, 19:20])

train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=4)

'''准备参数'''
step = 0.01  # 步长
random_number = random.uniform(0, 1)  # 生成0到1之间的随机小数
learning_rate = []
n_estimators = []
max_depth = []
min_child_weight = []
seed = []
subsample = []
colsample_bytree = []
gamma = []
reg_alpha = []
reg_lambda = []




'''把各参数写进小列表'''
for i in range(100):
    learning_rate.append(round(random_number / step) * step)  # 根据步长进行取整
for i in range(500):
    n_estimators.append(random.randrange(1, 501, 1))
for i in range(10):
    max_depth.append(random.randrange(1, 11, 1))
for i in range(10):
    min_child_weight.append(random.randrange(1, 11, 1))
for i in range(10):
    seed.append(random.randrange(random.randrange(1, 11, 1)))

'''计算总循环运算的次数'''
loop_counts = len(learning_rate) * len(n_estimators) * len(max_depth) * len(min_child_weight) * len(seed)


'''把小列表合成总列表'''
for i in range(loop_counts):

    print(learning_rate)
    list_table = [learning_rate, n_estimators, max_depth, min_child_weight, seed]
    whole_table = np.array(list_table)  # 把个参数组成array数组好引用
    print(whole_table)

#

#     other_params = {'learning_rate': learning_rate, 'n_estimators': n_estimators, 'max_depth': max_depth,
#                     'min_child_weight'
#                     : min_child_weight, 'seed': 2,
#                     'subsample': 0.8, 'colsample_bytree': 0.8, 'gamma': 0, 'reg_alpha': 0, 'reg_lambda': 1}
#
#     multioutputregressor = MultiOutputRegressor(
#         xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)
#
#     check = multioutputregressor.predict(test_X)
#     # print(check)
#     # print(test_y)
#     r2 = r2_score(check, test_y)
#
#     print("计算得出的r方为：", r2)
#
# '''绘图'''
# plt.title("XGBoost流动度回归")
# plt.plot(test_y, color='#006F6E', label="原值")
# plt.plot(check, color='#FF9C29', label="预测值")
# plt.legend()
# plt.show()
