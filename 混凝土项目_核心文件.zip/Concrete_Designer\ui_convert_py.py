# 广东工业大学
# 李俊赞
#  开发时间:  9/17/2023 3:43 下午

import os
import os.path


# UI文件所在的路径
dir = './'

# 列出该目录下的所有UI文件
def list_ui_file():
    list = []
    files = os.listdir(dir)
    for filename in files:
        #print(dir+os.sep+f)
        #print(filename)
        if os.path.splitext(filename)[1] == '.ui':
            list.append(filename)
    return list

# 把扩展名为.ui的文件改为.py文件
def transPyFile(filename):
