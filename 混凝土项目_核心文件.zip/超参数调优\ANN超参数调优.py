import pandas as pd
import numpy as np
import lightgbm as lg

from sklearn.model_selection import train_test_split
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import GridSearchCV
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor  # 调用模型
from sklearn.neural_network import MLPRegressor

pd.set_option('display.max_columns', None)  # 结果显示所有列
pd.set_option('display.max_rows', None)  # 结果显示所行行

# 导入数据
# 2.原数据225个原数据7：3拆分
data2 = pd.read_csv('testdata.csv')
data1, data2 = train_test_split(data2, test_size=0.3)

# 创建训练集
train_x = data1.iloc[:, 0:9]
train_y = data1.iloc[:, 9]

# 写你想要优化的超参数，注意各模型的各个超参数会有它的数据类型，划分的时候一定注意这点>比如范围或一定要整数的
parameters = {
    'learning_rate_init': (0.001, 0.005, 0.01, 0.02, 0.05, 0.1),
    'hidden_layer_sizes': ((10, 10), (10, 12), (10, 14), (10, 16), (10, 18), (10, 20),
                           (12, 10), (12, 12), (12, 14), (12, 16), (12, 18), (12, 20),
                           (14, 10), (14, 12), (14, 14), (14, 16), (14, 18), (14, 20),
                           (16, 10), (16, 12), (16, 14), (16, 16), (16, 18), (16, 20),
                           (18, 10), (18, 12), (18, 14), (18, 16), (18, 18), (18, 20),
                           (20, 10), (20, 12), (20, 14), (20, 16), (20, 18), (20, 20))}
# (14, 10), (14, 12), (14, 14), (14, 16), (14, 18), (14, 20),
# (16, 10), (16, 12), (16, 14), (16, 16), (16, 18), (16, 20),
# (18, 10), (18, 12), (18, 14), (18, 16), (18, 18), (18, 20),
# (20, 10), (20, 12), (20, 14), (20, 16), (20, 18), (20, 20),
# (12, 10), (12, 12), (12, 14), (12, 16), (12, 18), (12, 20),

# print(parameters)

xlf = MLPRegressor(max_iter=100000)  # 定义你这次想优化的什么模型的超参数#LGBMRegressor

# 下面就是gridsearch的具体调用逻辑，注意grid模型里面的函数不要调错
n_folds = 5
gsearch = GridSearchCV(xlf, param_grid=parameters, cv=n_folds, refit=True)  # 这步就是核心代码，调用xlf迭代parameters里面的各种超参数组合
gsearch.fit(train_x, train_y)

# 这里就是一个简单的输出结果以及多个超参数的循环迭代输出，注意这里只能循环调用dict,所以parameters的数据类型一定是dict{}
print("Best score: %0.3f" % gsearch.best_score_)
for param_name in sorted(parameters.keys()):
    print("\t%s: %r" % (param_name, gsearch.best_params_[param_name]))
