# Machine Learning-Driven Prediction of Mechanical Properties for 3D Printed Concrete

## 项目简介 / Project Overview

本项目专注于使用机器学习技术预测3D打印混凝土的力学性能，包括抗压强度(CS)和抗折强度(FS)。机械性能是3D打印混凝土的关键指标，直接影响结构的承载能力和安全性 <mcreference link="https://github.com/Marvin-LiJunZan/Machine-learning-driven-prediction-of-mechanical-properties-for-3D-printed-concrete.git" index="0">0</mcreference>。

This project focuses on using machine learning techniques to predict the mechanical properties of 3D printed concrete, including compressive strength (CS) and flexural strength (FS). Mechanical properties are key to 3D printed concrete because they directly affect the load-bearing capacity and safety of the structure.

## 数据集 / Dataset

我们收集了大量相关文献数据，构建了包含以下内容的数据集 <mcreference link="https://github.com/Marvin-LiJunZan/Machine-learning-driven-prediction-of-mechanical-properties-for-3D-printed-concrete.git" index="0">0</mcreference>：
- **抗压强度数据**: 254条数据
- **抗折强度数据**: 210条数据

We consulted a large number of relevant literature and collected data to build a dataset containing:
- **Compressive Strength Data**: 254 data points
- **Flexural Strength Data**: 210 data points

### 特征变量 / Feature Variables
- PO水泥强度等级 (PO Cement Strength Grade)
- PO水泥含量 (PO Cement Content)
- SAC水泥强度等级 (SAC Cement Strength Grade)
- SAC水泥含量 (SAC Cement Content)
- 粉煤灰含量 (Fly Ash Content)
- 矿粉含量 (Mineral Powder Content)
- 硅灰含量 (Silica Fume Content)
- 水胶比 (Water-Binder Ratio)
- 胶砂比 (Binder-Sand Ratio)
- 减水剂掺量 (Water Reducer Content)
- 增稠剂掺量 (Thickener Content)
- 速凝剂掺量 (Accelerator Content)
- 缓凝剂掺量 (Retarder Content)
- 保水剂掺量 (Water Retention Agent Content)
- 纤维含量 (Fiber Content)

## 机器学习模型 / Machine Learning Models

项目实现了多种机器学习算法 <mcreference link="https://github.com/Marvin-LiJunZan/Machine-learning-driven-prediction-of-mechanical-properties-for-3D-printed-concrete.git" index="0">0</mcreference>：

### 主要算法 / Main Algorithms
1. **BP神经网络** (BP Neural Network)
2. **随机森林** (Random Forest)
3. **XGBoost**
4. **CatBoost**
5. **支持向量机** (Support Vector Machine)
6. **决策树回归** (Decision Tree Regression)
7. **高斯回归** (Gaussian Regression)

### 优化算法 / Optimization Algorithms
- **遗传算法-BP神经网络** (GA-BP Neural Network)
- **贝叶斯优化** (Bayesian Optimization)
- **网格搜索** (Grid Search)

## 项目结构 / Project Structure

```
├── BP神经网络/              # BP Neural Network implementations
├── XGBoost/                 # XGBoost regression models
├── 随机森林/                # Random Forest models
├── GA-BP神经网络/           # Genetic Algorithm optimized BP networks
├── 决策树回归/              # Decision Tree regression
├── 支持向量机.py            # Support Vector Machine
├── 高斯回归/                # Gaussian regression
├── 数据文件/                # Dataset files
├── 超参数调优/              # Hyperparameter optimization
├── 参数重要性结果/          # Feature importance analysis
├── 性能指标图/              # Performance metrics visualization
├── Concrete_Designer/       # GUI application for concrete design
└── 流动性/                  # Flowability prediction models
```

## 主要功能 / Main Features

### 1. 力学性能预测 / Mechanical Property Prediction
- 抗压强度预测 (Compressive Strength Prediction)
- 抗折强度预测 (Flexural Strength Prediction)
- 流动度预测 (Flowability Prediction)

### 2. 模型优化 / Model Optimization
- 超参数调优 (Hyperparameter Tuning)
- 遗传算法优化 (Genetic Algorithm Optimization)
- 贝叶斯优化 (Bayesian Optimization)

### 3. 特征分析 / Feature Analysis
- 特征重要性分析 (Feature Importance Analysis)
- 相关性分析 (Correlation Analysis)
- 灰色关联分析 (Grey Relational Analysis)

### 4. 可视化工具 / Visualization Tools
- 性能指标雷达图 (Performance Metrics Radar Chart)
- 热力图分析 (Heatmap Analysis)
- 预测结果对比图 (Prediction Comparison Charts)

## 使用方法 / Usage

### 环境要求 / Requirements
```bash
pip install numpy pandas scikit-learn xgboost matplotlib seaborn
pip install tensorflow keras catboost
pip install eli5 shap
```

### 运行示例 / Running Examples

#### 1. XGBoost回归预测
```python
python XGBoost/XGBoost回归.py
```

#### 2. 随机森林预测
```python
python 随机森林/随机森林抗压强度.py
```

#### 3. GA-BP神经网络
```python
python GA-BP神经网络/bp\ +\ GA.py
```

#### 4. 混凝土设计器GUI
```python
python Concrete_Designer/main.py
```

## 性能评估 / Performance Evaluation

模型使用以下指标进行评估：
- **R²决定系数** (R-squared)
- **均方误差** (Mean Squared Error, MSE)
- **均方根误差** (Root Mean Squared Error, RMSE)
- **平均绝对误差** (Mean Absolute Error, MAE)
- **相关系数** (Correlation Coefficient)

## 贡献者 / Contributors

- Marvin Li (李俊赞)

## 许可证 / License

本项目采用MIT许可证 - 详见 [LICENSE](LICENSE) 文件

## 引用 / Citation

如果您在研究中使用了本项目，请引用：

```bibtex
@misc{li2024ml_concrete,
  title={Machine Learning-Driven Prediction of Mechanical Properties for 3D Printed Concrete},
  author={Li, Junzan},
  year={2024},
  url={https://github.com/Marvin-LiJunZan/Machine-learning-driven-prediction-of-mechanical-properties-for-3D-printed-concrete}
}
```

## 联系方式 / Contact

如有问题或建议，请通过GitHub Issues联系我们。

---

**注意**: 本项目仅供学术研究使用，实际工程应用请谨慎验证模型的准确性和可靠性。