import matplotlib.pyplot as plt
import matplotlib

matplotlib.use('TkAgg')
import numpy as np
import pandas as pd
import tensorflow
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
plt.rcParams['font.sans-serif'] = ['KaiTi']

data = pd.read_excel(r"C:\Marvin's project\混凝土项目\数据文件\数据集完善.xlsx", sheet_name="流动度")
x = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 19:20])
feature_names = ['水泥强度等级(MPa)', '水泥含量', '粉煤灰含量', '矿粉含量', '硅灰含量', '水胶比', '胶砂比', '减水剂掺量(%)', '增稠剂掺量(%)', '速凝剂掺量(%)',
                 '缓凝剂掺量(%)', '保水剂掺量(%)', '纤维含量(%)']
X = x
train_X, val_X, train_y, y_true = train_test_split(X, y, random_state=1)
train_y = train_y.ravel()
my_model = RandomForestRegressor(random_state=20).fit(train_X, train_y)
import eli5
from eli5.sklearn import PermutationImportance

y_pred = my_model.predict(val_X)

# print(y_pred)
# print(y_true)
y_true = y_true.ravel()

print('均方误差=', mean_squared_error(y_true, y_pred))
print('均方根误差=', np.sqrt(mean_squared_error(y_true, y_pred)))
print('平均绝对误差=', mean_absolute_error(y_true, y_pred))
print('R方=', r2_score(y_true, y_pred))
print('相关系数=', np.corrcoef(y_true, y_pred)[0, 1])
plt.plot(y_true, color='#006F6E', label='True Values')
plt.plot(y_pred, color='#FF9C29', label='Predicted Values')
plt.legend()
plt.title("流动度随机森林回归")
plt.show()
plt.savefig('流动度随机森林回归.png')
perm = PermutationImportance(my_model, random_state=1).fit(val_X, y_true)
eli5.show_weights(perm, feature_names=data.iloc[:, :13].columns.tolist())
