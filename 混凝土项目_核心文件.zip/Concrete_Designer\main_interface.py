# 广东工业大学
# 李俊赞
#  开发时间:  10/8/2023 12:53 上午
from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton, QPlainTextEdit

app = QApplication([])

window = QMainWindow()
window.resize(1000, 800)
window.move(300, 310)
window.setWindowTitle('Concrete Designer')
textEdit = QPlainTextEdit(window)
textEdit.setPlaceholderText("请输入薪资表")
textEdit.move(10, 25)
textEdit.resize(600, 700)

window.show()
app.exec_()
