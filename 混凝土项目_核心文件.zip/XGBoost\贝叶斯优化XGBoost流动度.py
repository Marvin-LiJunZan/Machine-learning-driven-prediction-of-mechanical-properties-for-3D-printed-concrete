# 广东工业大学
# 李俊赞
#  开发时间:  9/18/2023 7:58 下午
# 广东工业大学
# 李俊赞
#  开发时间:  9/18/2023 7:51 下午
import numpy as np
from matplotlib import pyplot as plt
from sklearn.multioutput import MultiOutputRegressor
import xgboost as xgb
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from bayes_opt import BayesianOptimization

plt.rcParams['font.sans-serif'] = ['KaiTi']
import warnings
import matplotlib

matplotlib.use('TkAgg')
warnings.filterwarnings("ignore")  # 忽略警告信息

# 获取数据
data = pd.read_excel("../数据文件/数据集完善.xlsx", sheet_name="流动度")
X = np.array(data.iloc[:, 2:15])
y = np.array(data.iloc[:, 19:20])
data1 = pd.read_excel("../数据文件/数据集完善.xlsx")
x1 = np.array(data.iloc[:, 2:15])
y1 = np.array(data.iloc[:, 19:20])
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=4)


# 定义目标函数（即要最大化的函数）
def target_function(learning_rate, n_estimators, max_depth, min_child_weight, seed, subsample, colsample_bytree,
                    gamma,
                    reg_alpha, reg_lambda):
    other_params = {'learning_rate': learning_rate, 'n_estimators': int(n_estimators), 'max_depth': int(max_depth),
                    'min_child_weight': int(min_child_weight), 'seed': int(seed), 'subsample': subsample,
                    'colsample_bytree': colsample_bytree, 'gamma': gamma, 'reg_alpha': reg_alpha,
                    'reg_lambda': reg_lambda}

    multioutputregressor = MultiOutputRegressor(
        xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)
    check = multioutputregressor.predict(test_X)
    r2 = r2_score(check, test_y)
    return r2


# 定义参数空间
pbounds = {'learning_rate': (0.01, 0.3), 'n_estimators': (100, 500), 'max_depth': (1, 10),
           'min_child_weight': (1, 10), 'seed': (1, 10), 'subsample': (0.5, 1), 'colsample_bytree': (0.5, 1),
           'gamma': (0, 1), 'reg_alpha': (0, 1), 'reg_lambda': (0, 1)}

# 使用贝叶斯优化算法搜索最佳参数组合
optimizer = BayesianOptimization(f=target_function, pbounds=pbounds)
optimizer.maximize(init_points=10, n_iter=50)

# 打印最佳参数组合和对应的R2值
best_params = optimizer.max['params']
best_r2 = optimizer.max['target']
print("最佳参数组合：", best_params)
print("最佳R2值：", best_r2)

# 使用最佳参数组合进行模型训练和预测
other_params = {'learning_rate': best_params['learning_rate'], 'n_estimators': int(best_params['n_estimators']),
                'max_depth': int(best_params['max_depth']),
                'min_child_weight': int(best_params['min_child_weight']),
                'seed': int(best_params['seed']), 'subsample': best_params['subsample'],
                'colsample_bytree': best_params['colsample_bytree'], 'gamma': best_params['gamma'],
                'reg_alpha': best_params['reg_alpha'], 'reg_lambda': best_params['reg_lambda']}

multioutputregressor = MultiOutputRegressor(
    xgb.XGBRegressor(objective='reg:squarederror', **other_params, silent=True)).fit(train_X, train_y)
check = multioutputregressor.predict(test_X)
r2 = r2_score(check, test_y)
print("使用最佳参数组合计算得出的R2值：", r2)

# 绘制预测结果
plt.title("贝叶斯优化XGBoost流动度回归")
plt.plot(test_y, label="原值")
plt.plot(check, c='r', label="预测值")
plt.legend()
plt.show()