# 项目上传指南

## 核心文件列表（按优先级排序）

### 1. 项目配置文件
- `README.md` ✅ 已创建
- `requirements.txt` ✅ 已创建  
- `.gitignore` ✅ 已创建

### 2. 主要算法实现
- `bp ga.py` - 遗传算法优化的BP神经网络
- `XGBoost/XGBoost回归.py` - XGBoost回归模型
- `随机森林/随机森林抗压强度.py` - 随机森林模型
- `GA-BP神经网络/BP_network.py` - BP网络核心实现
- `GA-BP神经网络/bp + GA.py` - GA-BP主程序

### 3. 其他重要算法
- `支持向量机.py` - SVM实现
- `决策树回归/流动度决策树回归.py` - 决策树回归
- `高斯回归/高斯回归.py` - 高斯回归模型

### 4. 超参数优化
- `超参数调优/XGboost超参数调优.py`
- `超参数调优/ANN超参数调优.py`
- `超参数调优/RandomForest超参数调优.py`

### 5. 特征分析
- `参数重要性结果/灰色关联.py`
- `相关性斯皮尔曼.py`

### 6. GUI应用
- `Concrete_Designer/main.py`
- `Concrete_Designer/Concrete_Designer.py`

### 7. 数据文件（选择性上传）
- `数据文件/数据集完善.xlsx` - 主要数据集
- `数据文件/Concrete_Data.xls` - 标准数据集

## 上传命令示例

```bash
# 进入项目目录
cd "c:\JunzanLi_project\混凝土项目"

# 初始化Git仓库
git init

# 添加所有文件
git add .

# 提交更改
git commit -m "Initial commit: Machine learning models for 3D printed concrete"

# 添加远程仓库
git remote add origin https://github.com/Marvin-LiJunZan/Machine-learning-driven-prediction-of-mechanical-properties-for-3D-printed-concrete.git

# 推送到GitHub
git branch -M main
git push -u origin main
```

## 注意事项

1. **文件大小限制**：GitHub单个文件不能超过100MB
2. **敏感信息**：确保不上传包含敏感信息的文件
3. **数据文件**：大型数据文件可以考虑使用Git LFS或单独存储
4. **编码问题**：确保中文文件名在Git中正确处理

## 项目亮点

- 实现了多种机器学习算法（BP、XGBoost、随机森林等）
- 包含遗传算法优化的神经网络
- 提供完整的超参数调优方案
- 具有GUI界面的混凝土设计器
- 全面的特征重要性分析
- 支持多种力学性能预测（抗压、抗折、流动度）